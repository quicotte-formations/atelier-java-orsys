package orsys.atelier.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Ex1 {

	public static void main(String[] args) {
		
		ArrayList<Integer> entiers = new ArrayList<Integer>();
		entiers.add(10);
		entiers.add(20);
		entiers.add(30);
		System.out.println( entiers );
		
		
		ArrayList bebetes= new ArrayList();
	}
}
