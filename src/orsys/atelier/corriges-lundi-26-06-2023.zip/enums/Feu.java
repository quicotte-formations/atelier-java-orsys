package orsys.atelier.enums;

public enum Feu {
	VERT, ORANGE, ROUGE
}
