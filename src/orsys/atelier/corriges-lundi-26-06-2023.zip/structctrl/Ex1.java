package orsys.atelier.structctrl;

public class Ex1 {
	public static void main(String[] args) {
		int a=2;
		int b=3;
		
		if(a<b) {
			System.out.println("a<b");
		}else if(a>b) {
			System.out.println("a>b");
		}else {
			System.out.println("a==b");
		}
	}
}
