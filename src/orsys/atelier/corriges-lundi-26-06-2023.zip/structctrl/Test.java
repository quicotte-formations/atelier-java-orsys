package orsys.atelier.structctrl;

import java.util.Arrays;

public class Test {

	public static void main(String[] args) {
		
		String[] tab = "vert, jaune, rouge".split(", ");
		
		System.out.println( Arrays.asList(tab) );
	}
}
