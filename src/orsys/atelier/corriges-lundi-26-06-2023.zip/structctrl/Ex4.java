package orsys.atelier.structctrl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Ex4 {
	public static void main(String[] args) {
		
		int res = 1;
		
		for(int i=1;i<=9;i++) {
			res = res * i;
		}
		
		System.out.println( res );
	}
}
