package orsys.atelier.tab;

public class Ex1 {

	public static void main(String[] args) {
		int[] entiers = new int[3];
		System.out.println( entiers.length );
	}
}
