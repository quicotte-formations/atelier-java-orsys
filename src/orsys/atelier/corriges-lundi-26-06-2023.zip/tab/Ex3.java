package orsys.atelier.tab;

public class Ex3 {

	public static void main(String[] args) {
		int[] suite = {10,20,0};
		
		suite[2]=suite[0] + suite[1];
		
		System.out.println( suite[2] );
	}
}
