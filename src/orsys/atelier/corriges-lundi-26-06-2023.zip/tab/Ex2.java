package orsys.atelier.tab;

public class Ex2 {

	public static void main(String[] args) {
		int[] nombres = new int[3];
		
		System.out.println( nombres[0] );
	}
}
