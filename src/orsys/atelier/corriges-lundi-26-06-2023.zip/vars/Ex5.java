package orsys.atelier.vars;

import java.util.Scanner;

public class Ex5 {

	public static void main(String[] args) {
		
		
		int res = 9;
		
		boolean resultat = res%2 == 0;
		
		System.out.println(resultat);
	}
}
