package orsys.atelier.vars;

public class Ex4 {

	public static void main(String[] args) {
		
		int a = 99 % 10;
		
		System.out.println("Reste de 99 par 10 est : " + a);
	}
}
