package orsys.atelier.vars;

public class Ex3 {

	public static void main(String[] args) {
		String a = "1";
		String b = "2";
		int res = Integer.parseInt(a) + Integer.parseInt(b);
		
		System.out.println(res);
	}
}
